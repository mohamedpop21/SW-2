package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Achievement {
	private String PlayerEmail;
	private String gameName;
	private int Score;
	public String getPlayerEmail() {
		return PlayerEmail;
	}
	public void setPlayerEmail(String playerEmail) {
		PlayerEmail = playerEmail;
	}
	public String getGameName() {
		return gameName;
	}
	public void setGameName(String gameName) {
		this.gameName = gameName;
	}
	public int getScore() {
		return Score;
	}
	public void setScore(int score) {
		Score = score;
	}
	public Achievement(String playerEmail, String gameName, int score) {
		super();
		PlayerEmail = playerEmail;
		this.gameName = gameName;
		Score = score;
	}
	
	public Achievement(){
		
	}
	public void addAchieve( String Email,String Gamename ,int score) throws ClassNotFoundException {
		connection();
		String url = "jdbc:mysql://localhost/my_game_db";
		String name = "root";
		String pass = "";
		Connection con;
		
		try {
			con = DriverManager.getConnection(url, name, pass);
			//System.out.println("medhat");
			String sql = "insert into achievement (PlayerEmail,gameName,Score)"
					+ "values(\"" + Email + "\",\"" +Gamename + "\"," +score+ ")";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.execute();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public ArrayList<Achievement> returnAvhieve(String email) throws ClassNotFoundException {
		connection();
		String url = "jdbc:mysql://localhost/my_game_db";
		String name = "root";
		String pass = "";
		Connection con;
		ArrayList<Achievement> game=new ArrayList<Achievement>();
		
		try {
			con = DriverManager.getConnection(url, name, pass);
			System.out.println("medhat");
			String queryCheck1 = "SELECT* from achievement where PlayerEmail= \"" + email + "\"";
			Statement st1 = con.createStatement();
			ResultSet rs1 = st1.executeQuery(queryCheck1);
			while (rs1.next()) {
				Achievement A=new Achievement();
			
				A.setPlayerEmail(rs1.getString("PlayerEmail"));
				A.setGameName(rs1.getString("gameName"));
				A.setScore(rs1.getInt("Score"));
				game.add(A);
			}

		
	}catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		return game;}
	
	public static void connection() throws ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
	}
	
}

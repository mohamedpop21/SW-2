package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Game {
	private String GameName;
	private String Type;
	private String CourseName;
	private int MaxSCore;
	private String TeacherEmail;
	private String BestOne;
	private int numberOfQuestion;
	private ArrayList<MCQ> mcq;
	private ArrayList<True_False> T_F;

	public String getGameName() {
		return this.GameName;
	}

	public void setGameName(String gameName) {
		GameName = gameName;
	}

	public String getType() {
		return Type;
	}

	public void setType(String type) {
		Type = type;
	}

	public String getCourseName() {
		return CourseName;
	}

	public void setCourseName(String courseName) {
		CourseName = courseName;
	}

	public int getMaxSCore() {
		return MaxSCore;
	}

	public void setMaxSCore(int maxSCore) {
		MaxSCore = maxSCore;
	}

	public String getTeacherEmail() {
		return TeacherEmail;
	}

	public void setTeacherEmail(String teacherEmail) {
		TeacherEmail = teacherEmail;
	}

	public String getBestOne() {
		return BestOne;
	}

	public void setBestOne(String bestOne) {
		BestOne = bestOne;
	}

	public int getNumberOfQuestion() {
		return numberOfQuestion;
	}

	public void setNumberOfQuestion(int numberOfQuestion) {
		this.numberOfQuestion = numberOfQuestion;
	}

	public ArrayList<MCQ> getMcq() {
		return mcq;
	}

	public void setMcq(ArrayList<MCQ> mcq) {
		this.mcq = mcq;
	}

	public ArrayList<True_False> getT_F() {
		return T_F;
	}

	public void setT_F(ArrayList<True_False> t_F) {
		T_F = t_F;
	}

	public Game(String gameName, String type, String courseName, int maxSCore, String teacherEmail, String bestOne,
			int numberOfQuestion, ArrayList<MCQ> mcq, ArrayList<True_False> t_F) {
		super();
		GameName = gameName;
		Type = type;
		CourseName = courseName;
		MaxSCore = maxSCore;
		TeacherEmail = teacherEmail;
		BestOne = bestOne;
		this.numberOfQuestion = numberOfQuestion;
		this.mcq = mcq;
		this.T_F = t_F;
	}

	public Game() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Game(Game game) {
		// TODO Auto-generated constructor stub
		GameName = game.getGameName();
		Type = game.getType();
		CourseName = game.getCourseName();
		MaxSCore = game.getMaxSCore();
		TeacherEmail = game.getTeacherEmail();
		BestOne =game.getBestOne();
		this.numberOfQuestion = game.getNumberOfQuestion();
		this.mcq =game.getMcq();
		this.T_F = game.getT_F();
	}

	public static void connection() throws ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
	}

	public ArrayList<String> showgames(String Coursename) throws ClassNotFoundException {
		ArrayList<String> list = new ArrayList<String>();
		connection();
		String url = "jdbc:mysql://localhost/my_game_db";
		String name = "root";
		String pass = "";
		Connection con;
		try {
			con = DriverManager.getConnection(url, name, pass);
			System.out.println("medhat");
			String queryCheck1 = "SELECT GameName from Game where CourseName= \"" + Coursename + "\"";
			Statement st1 = con.createStatement();
			ResultSet rs1 = st1.executeQuery(queryCheck1);
			while (rs1.next()) {
				list.add(rs1.getString("GameName"));

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	public Game slectgame(String Gamename) throws ClassNotFoundException {
		Game game = new Game();
		connection();
		String url = "jdbc:mysql://localhost/my_game_db";
		String name = "root";
		String pass = "";
		Connection con;
		try {
			con = DriverManager.getConnection(url, name, pass);
			System.out.println("medhat");
			String queryCheck1 = "SELECT* from Game where GameName= \"" + Gamename + "\"";
			Statement st1 = con.createStatement();
			System.out.println("hala");
			ResultSet rs1 = st1.executeQuery(queryCheck1);
			System.out.println(Gamename);
			while (rs1.next()) {
				game.setGameName(rs1.getString("GameName"));
				game.setType(rs1.getString("Type"));
				game.setCourseName(rs1.getString("CourseName"));
				game.setMaxSCore(rs1.getInt("MaxSCore"));
				game.setTeacherEmail(rs1.getString("TeacherEmail"));
				game.setBestOne(rs1.getString("BestOne"));
				game.setNumberOfQuestion(rs1.getInt("numberOfQuestion"));

			}
			if (game.getType().equals("TF")) {
				
				ArrayList<True_False> arraytf = new ArrayList<True_False>();
				True_False gm = new True_False();
				queryCheck1 = "SELECT Question,answer,Point from true_false where GameName= \"" + game.getGameName() + "\"";
				st1 = con.createStatement();
				System.out.println("hala");
				rs1 = st1.executeQuery(queryCheck1);
				System.out.println("hala");
				while (rs1.next()) {
					gm.setQuestion(rs1.getString("Question"));
			//System.out.println(gm.getQuestion());
					gm.setAnswer(rs1.getString("answer"));
					gm.setPoint(rs1.getInt("Point"));
					arraytf.add(new True_False(rs1.getString("Question"), rs1.getString("answer"), rs1.getInt("Point")));

				}
				game.setT_F(arraytf);
				con.close();
				} else if (game.getType().equals("MCQ")) {
				ArrayList<MCQ> arraymcq = new ArrayList<MCQ>();
				MCQ gm = new MCQ();
				ArrayList<String> Ar = new ArrayList<String>();
				queryCheck1 = "SELECT* from mcq where GameName= \"" + game.getGameName() + "\"";
				Statement st2 = con.createStatement();
				ResultSet rs2 = st2.executeQuery(queryCheck1);
				while (rs1.next()) {
					gm.setQuestion(rs2.getString("Question"));
					//System.out.println(gm.getQuestion());
					Ar.add(rs2.getString("choice1"));
					Ar.add(rs2.getString("choice2"));
					Ar.add(rs2.getString("choice3"));
					Ar.add(rs2.getString("choice4"));
					gm.setChoice(Ar);
					gm.setAnswer(rs2.getString("answer"));
					gm.setPoint(rs2.getInt("Point"));
					System.out.println(gm.getQuestion());
					System.out.println(gm.getChoice().get(0));
					System.out.println(gm.getChoice().get(1));
					arraymcq.add(gm);

				}
				game.setMcq(arraymcq);
				con.close();
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return game;
	}
}

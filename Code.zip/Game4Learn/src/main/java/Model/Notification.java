package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Notification {
	String NotifiedEmail;
	String Description;

	public String getNotifiedEmail() {
		return NotifiedEmail;
	}

	public void setNotifiedEmail(String notifiedEmail) {
		NotifiedEmail = notifiedEmail;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	public Notification(String notifiedEmail, String description) {
		super();
		NotifiedEmail = notifiedEmail;
		Description = description;
	}

	public Notification() {

	}

	public Notification(Notification n) {
		super();
		this.NotifiedEmail = n.getNotifiedEmail();
		Description = n.getDescription();
	}

	public static void connection() throws ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
	}

	public void addNotificatin(Notification x) throws ClassNotFoundException {
		connection();
		String url = "jdbc:mysql://localhost/my_game_db";
		String name = "root";
		String pass = "";
		Connection con;
		try {
			con = DriverManager.getConnection(url, name, pass);
			String sql = "insert into notification (notifiedEmail,Description)" + "values(\"" + x.getNotifiedEmail()
					+ "\",\"" + x.getDescription() + "\")";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.execute();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public ArrayList<String> selectNotification(String Accountmail) throws ClassNotFoundException {

		ArrayList<String> ar = new ArrayList<String>();
		connection();
		String url = "jdbc:mysql://localhost/my_game_db";
		String name = "root";
		String pass = "";
		Connection con;
		try {
			con = DriverManager.getConnection(url, name, pass);
			String queryCheck = "SELECT description from notification WHERE notifiedEmail = \"" + Accountmail + "\"";
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(queryCheck); // execute the query,
														// and get a java
														// resultset
			while (rs.next()) {
				String x = new String();
				x=(rs.getString("notifiedEmail"));
				
				

				ar.add(x);
			}
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ar;
	}
}

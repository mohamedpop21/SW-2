package Model;

public class True_False {
	private String Question;
	private String answer;
	private  int Point=5;
	
	public True_False() {
		super();
		// TODO Auto-generated constructor stub
	}
	public True_False( String question, String answer, int point) {
		super();
	
		Question = question;
		this.answer = answer;
		Point = point;
	}
	public String getQuestion() {
		return Question;
	}
	public void setQuestion(String question) {
		Question = question;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public int getPoint() {
		return Point;
	}
	public void setPoint(int point) {
		Point = point;
	}
	
	
}

package Model;

import java.awt.Choice;
import java.util.ArrayList;

public class MCQ {

	public  String Question;
	public  ArrayList<String>choice;
	private String answer;
	private int Point=5;
	public String getQuestion() {
		return Question;
	}
	public void setQuestion(String question) {
		Question = question;
	}
	public ArrayList<String> getChoice() {
		return choice;
	}
	public void setChoice(ArrayList<String> choice) {
		this.choice = choice;
	}
	public String getAnswer() {
		return answer;
	}
	public void setPoint(int point) {
		Point = point;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public int getPoint() {
		return Point;
	}
	public MCQ(String question, ArrayList<String> choice, String answer) {
		super();
		Question = question;
		this.choice = choice;
		this.answer = answer;
	}
	public MCQ() {
		super();
		// TODO Auto-generated constructor stub
	}
	public MCQ(String string, String string2, String string3, String string4, String string5, String string6,
			int int1) {
		Question = string;
		choice=new ArrayList<String>();
		choice.add(string2);
		choice.add(string3);
		choice.add(string4);
		choice.add(string5);
		this.answer=string6;
		this.Point=int1;
		// TODO Auto-generated constructor stub
	}
	public static void connection() throws ClassNotFoundException
	{
		Class.forName("com.mysql.jdbc.Driver");
	}
	

}

package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Teacher extends Account {

	public Teacher() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Teacher(Account c) {
		super(c);
		// TODO Auto-generated constructor stub
	}

	public Teacher(String fname, String lname, String usrenName, String email, String password, String gender, int age,
			int maxScore,String type) {
		super(fname, lname, usrenName, email, password, gender, age, maxScore,"Teacher");
		// TODO Auto-generated constructor stub
	}

	public void addMcq(Game gam) throws ClassNotFoundException {
		connection();
		String url = "jdbc:mysql://localhost/my_game_db";
		String name = "root";
		String pass = "";
		Connection con;
		try {
			gam.setNumberOfQuestion(gam.getMcq().size());
			con = DriverManager.getConnection(url, name, pass);
			String sql = "insert into Game (GameName,Type,CourseName,MaxSCore,TeacherEmail,BestOne,numberOfQuestion)"
					+ "values(\"" + gam.getGameName() + "\",\"" + gam.getType() + "\",\"" + gam.getCourseName() + "\","
					+ gam.getMaxSCore() + ",\"" + gam.getTeacherEmail() + "\",\"" + gam.getBestOne() + "\","
					+ gam.getNumberOfQuestion() + ")";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.execute();
			for (int i = 0; i < gam.getMcq().size(); i++) {

				sql = "insert into mcq (GameName,Question,choice1,choice2,choice3,choice4,answer,Point)" + "values(\""
						+ gam.getGameName() + "\",\"" + gam.getMcq().get(i).getQuestion() + "\",\""
						+ gam.getMcq().get(i).getChoice().get(0) + "\",\"" + gam.getMcq().get(i).getChoice().get(1)
						+ "\",\"" + gam.getMcq().get(i).getChoice().get(2) + "\",\""
						+ gam.getMcq().get(i).getChoice().get(3) + "\",\"" + gam.getMcq().get(i).getAnswer() + "\","
						+ gam.getMcq().get(i).getPoint() + ")";
				pst = con.prepareStatement(sql);
				pst.execute();
			}
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void Addtf(Game gam) throws ClassNotFoundException {

		connection();
		String url = "jdbc:mysql://localhost/my_game_db";
		String name = "root";
		String pass = "";
		Connection con;
		try {
			gam.setNumberOfQuestion(gam.getT_F().size());
			con = DriverManager.getConnection(url, name, pass);
			String sql = "insert into Game (GameName,Type,CourseName,MaxSCore,TeacherEmail,BestOne,numberOfQuestion)"
					+ "values(\"" + gam.getGameName() + "\",\"" + gam.getType() + "\",\"" + gam.getCourseName() + "\","
					+ gam.getMaxSCore() + ",\"" + gam.getTeacherEmail() + "\",\"" + gam.getBestOne() + "\","
					+ gam.getNumberOfQuestion() + ")";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.execute();
			for (int i = 0; i < gam.getT_F().size(); i++) {

				sql = "insert into true_false (GameName,Question,answer,Point)" + "values(\"" + gam.getGameName()
						+ "\",\"" + gam.getT_F().get(i).getQuestion() + "\",\"" + gam.getT_F().get(i).getAnswer()
						+ "\"," + gam.getT_F().get(i).getPoint() + ")";
				pst = con.prepareStatement(sql);
				pst.execute();
			}
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	public void CanclGame(String gamename ) throws ClassNotFoundException {

		connection();
		String url = "jdbc:mysql://localhost/my_game_db";
		String name = "root";
		String pass = "";
		Connection con;
		try {
			con = DriverManager.getConnection(url,name,pass );
			String sql = "UPDATE `game` SET `Canceled`= yes WHERE GameName=\""+gamename+"\"";
			PreparedStatement pst=con.prepareStatement(sql);
			pst.execute();
			con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	public static void connection() throws ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
	}
public ArrayList<String>  CreatedGame(String Techermail) throws ClassNotFoundException {
		
		connection();
		String url = "jdbc:mysql://localhost/my_game_db";
		String name = "root";
		String pass = "";
		Connection con;
	ArrayList<String> names=new ArrayList<String>();
		try {
			con = DriverManager.getConnection(url, name, pass);
			System.out.println("medhat");
			String queryCheck1 = "SELECT  GameName from Game where TeacherEmail= \"" + Techermail + "\"";
			Statement st1 = con.createStatement();
			System.out.println("hala");
			
			ResultSet rs1 = st1.executeQuery(queryCheck1);
			
			String Name="";
				
			Name+=rs1.getString("TeacherEmail");
			names.add(Name);

			
			}
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return names;
	}
	
}

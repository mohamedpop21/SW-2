package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class Coment {

	String GameName;
	String ComenterEmai;
	String comenttxet;
	public Coment(){
		
	}
	public Coment(Coment c){
		this.GameName=c.getGameName();
		this.ComenterEmai=c.getComenterEmai();
		this.comenttxet=c.getComenttxet();
	}
	public Coment(String gameName, String comenterEmai, String comenttxet) {
		super();
		GameName = gameName;
		ComenterEmai = comenterEmai;
		this.comenttxet = comenttxet;
	}
	public String getGameName() {
		return GameName;
	}
	public void setGameName(String gameName) {
		GameName = gameName;
	}
	public String getComenterEmai() {
		return ComenterEmai;
	}
	public void setComenterEmai(String comenterEmai) {
		ComenterEmai = comenterEmai;
	}
	public String getComenttxet() {
		return comenttxet;
	}
	public void setComenttxet(String comenttxet) {
		this.comenttxet = comenttxet;
	}
	public static void connection() throws ClassNotFoundException
	{
		Class.forName("com.mysql.jdbc.Driver");
	}
	
	public void addComment(Coment x) throws ClassNotFoundException
	{
		connection();
		String url = "jdbc:mysql://localhost/my_game_db";
		String name = "root";
		String pass = "";
		Connection con;
		try {
			con = DriverManager.getConnection(url,name,pass );
			String sql="insert into comment (GameName,commenterEmail,commenttxet)"
					+ "values(\""+x.getGameName()+"\",\""+x.getComenterEmai()+"\",\""+x.getComenttxet()+"\")";
			PreparedStatement pst=con.prepareStatement(sql);
			pst.execute();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	public ArrayList<Coment> selectComment(String gamename) throws ClassNotFoundException
	{
		
		ArrayList<Coment> ar=new ArrayList<Coment>();
		connection();
		String url = "jdbc:mysql://localhost/my_game_db";
		String name = "root";
		String pass = "";
		Connection con;
		try {
			con = DriverManager.getConnection(url,name,pass );
			String queryCheck = "SELECT * from comment WHERE GameName = \"" +gamename  +"\"" ;
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(queryCheck); // execute the query, and get a java resultset
			while (rs.next()) {
				Coment x=new Coment();
				x.setGameName(rs.getString("GameName"));
				x.setComenterEmai(rs.getString("ComenterEmai"));
				x.setComenttxet(rs.getString("comenttxet"));
			
				ar.add(x);
		      }
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ar;
	}
}

package Controller;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import Model.Account;
import Model.Achievement;
import Model.Coment;
import Model.Course;
import Model.Game;
import Model.MCQ;
import Model.Notification;
import Model.Teacher;
import Model.True_False;

@Controller
public class UserController {
	
	Account acut=new Account();
	private Course course = new Course();
	private Game game = new Game();
	private ArrayList<MCQ> MCQARRY = new ArrayList<MCQ>();
	private ArrayList<True_False> TFARRY = new ArrayList<True_False>();
	private int Qcounter;
	ArrayList<MCQ> M=new ArrayList<MCQ>();
	ArrayList<True_False> MM=new ArrayList<True_False>();
	ArrayList<String> Qus=new ArrayList<String>();
	@RequestMapping("/")
	public String greeting() {

		return "mainpage";
	}

	@RequestMapping("/SingUpAsSTudent")
	public String SingUpS() {
		return "SingUpAsSTudent";
	}

	@RequestMapping("/LogInAsSTusdent")
	public String LoginSt() {
		return "LogInAsSTusdent";
	}

	@RequestMapping("/addStudent")
	public String adNewUser(@RequestParam String Fname, @RequestParam String Lname, @RequestParam String Uname,
			@RequestParam String Email, @RequestParam String Passwoed, @RequestParam int Age,
			@RequestParam String Gender) throws ClassNotFoundException {
	
		acut = new Account(Fname, Lname, Uname, Email, Passwoed, Gender, Age, 0, "Student");
		
		if (acut.registeration(acut)) {

			
			return "studentHomePage";
		}

		else
			return "SingUpAsSTudent";
	}

	@RequestMapping("/loginStudent")
	public String LoGIN(@RequestParam String Email, @RequestParam String Passwoed) throws ClassNotFoundException {
		acut = new Account(acut.CheckValidation(Email, Passwoed));
		if (Email.equals(acut.getEmail()) & Passwoed.equals(acut.getPassword())&acut.getType().equals("Student")) {
			return "studentHomePage";
		} else {
			return "LogInAsSTusdent";
		}
	}
	@RequestMapping("/SingUpAsTeacher")
	public String SinUp() {
		return "SingUpAsTeacher";
	}

	@RequestMapping("/LogInAsTeacher")
	public String Log() {
		return "LogInAsTeacher";
	}

	@RequestMapping("/addTecher")
	public String addNewUser(@RequestParam String Fname, @RequestParam String Lname, @RequestParam String Uname,
			@RequestParam String Email, @RequestParam String Passwoed, @RequestParam int Age,
			@RequestParam String Gender) throws ClassNotFoundException {
		 //Teacher account = new Teacher( acut);
		// account=new Teacher( Fname, Lname, Uname, Email, Passwoed,
		// Gender,Age,0);
		 acut.setFname(Fname);
		 acut.setLname(Lname);
		 acut.setUsrenName(Uname);
		 acut.setEmail(Email);
		 acut.setPassword(Passwoed);
		 acut.setGender(Gender);
		 acut.setAge(Age);
		 acut.setMaxScore(0);
		 acut.setType("Teacher");
		if (acut.registeration(acut)) {

			//System.out.println("MEEEEEEEEEDHHHAAATT");
			return "TeacherHomPage";
		}

		else
			return "SingUpAsTeacher";
	}

	@RequestMapping("/logintecher")
	public String loginastech(@RequestParam String Email, @RequestParam String Passwoed) throws ClassNotFoundException {
		//Teacher account = new Teacher( acut);
		 acut =new Account( acut.CheckValidation(Email, Passwoed)) ;
		if (Email.equals(acut.getEmail()) & Passwoed.equals(acut.getPassword())& acut.getType().equals("Teacher")) {

			return "TeacherHomPage";
		} else {
			return "LogInAsTeacher";
		}
	}

	@RequestMapping("/CreateCourse")
	public String create() {
		return "CreateCourse";
	}

	@RequestMapping("/CREATCOURSE")
	public String creatcourse(@RequestParam String CourseName, @RequestParam String Description)
			throws ClassNotFoundException {
		Teacher account = new Teacher( acut);

		Course course = new Course(CourseName, Description, account.getEmail());
		course.setCourse(course);
		return "TeacherHomPage";
	}
@RequestMapping("/curseseen")
public String gohome(){
	if(acut.getType().equals("Student"))
	{
		return "studentHomePage";
	}
	else {
		
	
	return "TeacherHomPage";}
}
	@RequestMapping("/ShowCourses")
	public ModelAndView showCour() throws ClassNotFoundException {
		ModelAndView mv = new ModelAndView();
		ArrayList<String> arr = new ArrayList<String>();
		arr = course.showcorses();
		mv.setViewName("ShowCourses");
		mv.addObject("courses", arr);
		return mv;
	}

	@RequestMapping("/CreateGame")
	public ModelAndView showCours() throws ClassNotFoundException {
		ModelAndView mv = new ModelAndView();
		ArrayList<String> arr = new ArrayList<String>();
		arr = course.showcorses();
		mv.setViewName("AddGame");
		mv.addObject("courses", arr);
		return mv;
	}

	@RequestMapping("/selectCourse")
	public String slectCour(@RequestParam String GameName, @RequestParam String courseName, @RequestParam String answer)
			throws ClassNotFoundException {
		game.setGameName(GameName);
		game.setCourseName(courseName);
		game.setTeacherEmail(acut.getEmail());
		Achievement A=new Achievement();
		ArrayList<String > player=new ArrayList<String>(A.returnplyer(courseName));
		//notify anew game 
		for (int i=0;i<player.size();i++){
			Notification N=new Notification();
			N.setNotifiedEmail(player.get(i));
			N.setDescription(acut.getFname()+" added a new Game in "+courseName+"Cours ");
			N.addNotificatin(N);
		}

		if (answer.equals("MCQ")) {

			return "AddMCQ";
		} else {
			return "AddTF";
		}

	}

	@RequestMapping("/addmcqQuestion")
	public String addQ(@RequestParam String question, @RequestParam String Choice1, @RequestParam String Choice2,
			@RequestParam String Choice3, @RequestParam String Choice4, @RequestParam String answer,
			@RequestParam int answerQ) throws ClassNotFoundException {
		Teacher account = new Teacher( acut);
		MCQ gam = new MCQ();
		ArrayList<String> ar = new ArrayList<String>();

		gam.setQuestion(question);
		ar.add(Choice1);
		ar.add(Choice2);
		ar.add(Choice3);
		ar.add(Choice4);
		gam.setChoice(ar);
		gam.setAnswer(ar.get(answerQ - 1));
		MCQARRY.add(gam);

		if (answer.equals("Yes")) {
			return "AddMCQ";
		} else {
			game.setType("MCQ");
			game.setMcq(MCQARRY);
			account.addMcq(game);
			game = new Game();
			System.out.println("Game added sucsussfuly ");
			return "TeacherHomPage";
		}

	}

	@RequestMapping("/addT_FQuestion")
	public String addT_F(@RequestParam String question, @RequestParam String answer, @RequestParam String answerQ)
			throws ClassNotFoundException {
		Teacher account = new Teacher( acut);
		True_False gamtf = new True_False();

		gamtf.setQuestion(question);
		gamtf.setAnswer(answerQ);
		TFARRY.add(gamtf);
		if (answer.equals("Yes")) {
			return "AddTF";
		} else {
			game.setType("TF");
			game.setT_F(TFARRY);
			account.Addtf(game);
			game = new Game();
			System.out.println("Game added sucsussfuly ");
			return "TeacherHomPage";
		}

	}

	@RequestMapping("/PlayGame")
	public ModelAndView RetunCourses() throws ClassNotFoundException {
		ModelAndView mv = new ModelAndView();
		ArrayList<String> arr = new ArrayList<String>();
		arr = course.showcorses();
		mv.setViewName("PlayGame");
		mv.addObject("ccourses", arr);
		return mv;
	}
	@RequestMapping("/selctgames")
	public ModelAndView RetunGamesname(@RequestParam String coursename) throws ClassNotFoundException {
		ModelAndView mv = new ModelAndView();
		ArrayList<String> arr = new ArrayList<String>();
		System.out.println(coursename);
		arr = game.showgames(coursename );
		mv.setViewName("PlayGame");
		mv.addObject("gamesname", arr);
		return mv;
	}
	@RequestMapping("/selectgame")
	public String RetunGames(Model model,@RequestParam String gamnam) throws ClassNotFoundException {
		
		Game gam=new Game();
		gam=game.slectgame(gamnam);
		game.setGameName(gamnam);
		Qcounter=0;
				
			if(	gam.getType().equals("MCQ")){
				
				System.out.println("ay haga");
			M=new ArrayList<MCQ>();
			M=gam.getMcq();
			System.out.println("asd"+M.get(Qcounter).getQuestion());
			System.out.println("ay haga");
			model.addAttribute("questions", M.get(Qcounter));
			return "Playing";
			}
			else if(gam.getType().equals("TF")){
				
				
				MM=gam.getT_F();
				model.addAttribute("questions", MM.get(Qcounter));
				for(int i=0;i<MM.size();i++){
				System.out.println(i+"><"+MM.get(i).getQuestion());
				System.out.println(MM.get(i).getAnswer());
				System.out.println(MM.get(i).getPoint());
				}
				
				System.out.println(MM.size());
				return "PlayingTF";
			}
		
		return "TeacherHomPage";
	}
	@RequestMapping("/nQuestion")
	public String upda(Model model ,@RequestParam int Answe) throws ClassNotFoundException{
		//Teacher account = new Teacher( acut);
		
		if(M.get(Qcounter).getAnswer().equals(M.get(Qcounter).getChoice().get(Answe-1))){
			acut.setMaxScore(acut.getMaxScore()+M.get(Qcounter).getPoint());
		}
		Qcounter++;
		if(Qcounter>=M.size()){
			Achievement a=new Achievement();
			a.addAchieve(acut.getEmail(), game.getGameName(),game.getCourseName(), acut.getMaxScore());
			if(acut.getType().equals("Teacher"))
			{
			return "TeacherHomPage";
			}
			return "studentHomePage";
		}
		System.out.println(MM.get(Qcounter).getQuestion());
		System.out.println(MM.get(Qcounter).getAnswer());
		System.out.println(MM.get(Qcounter).getPoint());
		
		model.addAttribute("questions", M.get(Qcounter));
		return "Playing";
	
	}
	@RequestMapping("/nextQuestion")
	public String update(Model model ,@RequestParam String Answe) throws ClassNotFoundException{
		//Teacher account = new Teacher( acut);
		
		if(MM.get(Qcounter).getAnswer().equals(Answe)){
			acut.setMaxScore(acut.getMaxScore()+MM.get(Qcounter).getPoint());
		}
		Qcounter++;
		if(Qcounter>=MM.size()){
			Achievement a=new Achievement();
			a.addAchieve(acut.getEmail(), game.getGameName(),game.getCourseName(), acut.getMaxScore());
			if(acut.getType().equals("Teacher"))
			{
			return "TeacherHomPage";
			}
			return "studentHomePage";
		}
		System.out.println(MM.get(Qcounter).getQuestion());
		System.out.println(MM.get(Qcounter).getAnswer());
		System.out.println(MM.get(Qcounter).getPoint());
		
		model.addAttribute("questions", MM.get(Qcounter));
		return "PlayingTF";
	
	}
	
	@RequestMapping("/Achievment")
	public String achve(Model modle) throws ClassNotFoundException{
		Achievement A=new Achievement();
		ArrayList<Achievement>ac= new ArrayList<Achievement>();
		ac=A.returnAvhieve(acut.getEmail());
		modle.addAttribute("Ach",ac);
		
		return "achivment";
		
	}
	@RequestMapping("/comment")
	public ModelAndView RetunCourse() throws ClassNotFoundException {
		ModelAndView mv = new ModelAndView();
		ArrayList<String> arr = new ArrayList<String>();
		arr = course.showcorses();
		mv.setViewName("Comment");
		mv.addObject("ccourses", arr);
		return mv;
	}
	@RequestMapping("/selctgamestocomment")
	public ModelAndView RetunGamesnam(@RequestParam String coursename) throws ClassNotFoundException {
		ModelAndView mv = new ModelAndView();
		ArrayList<String> arr = new ArrayList<String>();
		System.out.println(coursename);
		arr = game.showgames(coursename );
		mv.setViewName("Coment");
		mv.addObject("gamesname", arr);
		return mv;
	}
	@RequestMapping("/selectgametocommnt")
	public String Retuncomment(Model model,@RequestParam String gamnam ,@RequestParam String Commenttext) throws ClassNotFoundException {
	Coment com=	new Coment();
	Game m=new Game();
	Notification N=new Notification();
	com.selectComment(gamnam);
	com.setComenterEmai(acut.getEmail());
	com.setComenttxet(Commenttext);
	com.addComment(com);
	N.selectNotification(m.slectteacher(gamnam));
	N.setDescription(acut.getFname()+"has been commented on your Game ");
	N.addNotificatin(N);
	
		
		if(acut.getType().equals("Student"))
		{
			return "studentHomePage";
		}
		else {
			
		
		return "TeacherHomPage";}
	}
	@RequestMapping("/ShowCourses")
	public ModelAndView CancelGame() throws ClassNotFoundException {
		ModelAndView mv = new ModelAndView();
		Teacher account = new Teacher( acut);
		ArrayList<String> arr = new ArrayList<String>();
		arr = account.CreatedGame(acut.getEmail());
		mv.setViewName("Cancel");
		mv.addObject("gamesname", arr);
		return mv;
	}
	@RequestMapping("/canceledgame")
	public String canced(@RequestParam String gamnam) throws ClassNotFoundException {
		Teacher account = new Teacher( acut);
		account.CanclGame(gamnam);
		return "TeacherHomPage";}
	
	@RequestMapping("/ShowNoty")
	public ModelAndView showNoty() throws ClassNotFoundException {
		ModelAndView mv = new ModelAndView();
	Notification N=new Notification();
		ArrayList<String> arr = new ArrayList<String>();
          arr=N.selectNotification(acut.getEmail());
		mv.setViewName("ShowNotification");
		mv.addObject("gamesname", arr);
		return mv;
}
	@RequestMapping("/Notify")
	public String goh(){
		if(acut.getType().equals("Student"))
		{
			return "studentHomePage";
		}
		else {
			
		
		return "TeacherHomPage";}
	}
	}

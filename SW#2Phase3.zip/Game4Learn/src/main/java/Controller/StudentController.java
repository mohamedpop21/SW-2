package Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import Model.Account;

@Controller
public class StudentController {
	private Account account;

	@RequestMapping("/")
	public String greeting() {

		return "mainpage";
	}

	@RequestMapping("/SingUpAsSTudent")
	public String SingUpS() {
		return "SingUpAsSTudent";
	}

	@RequestMapping("/LogInAsSTusdent")
	public String LoginSt() {
		return "LogInAsSTusdent";
	}

	@RequestMapping("/addStudent")
	public String adNewUser(@RequestParam String Fname, @RequestParam String Lname, @RequestParam String Uname,
			@RequestParam String Email, @RequestParam String Passwoed, @RequestParam int Age,
			@RequestParam String Gender) throws ClassNotFoundException {

		account = new Account(Fname, Lname, Uname, Email, Passwoed, Gender, Age, 0, "Student");
		if (account.registeration(account)) {

			System.out.println("MEEEEEEEEEDHHHAAATT");
			return "studentHomePage";
		}

		else
			return "SingUpAsSTudent";
	}

	@RequestMapping("/loginStudent")
	public String LoGIN(@RequestParam String Email, @RequestParam String Passwoed) throws ClassNotFoundException {
		account = new Account(account.CheckValidation(Email, Passwoed));
		if (Email.equals(account.getEmail()) & Passwoed.equals(account.getPassword())) {
			return "studentHomePage";
		} else {
			return "LogInAsSTusdent";
		}
	}

}

package Controller;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import Model.Course;
import Model.Game;
import Model.MCQ;
import Model.Teacher;
import Model.True_False;

@Controller
public class TeacherController {
	private Teacher account = new Teacher();
	private Course course = new Course();
	private Game game = new Game();
	private ArrayList<MCQ> MCQARRY = new ArrayList<MCQ>();
	private ArrayList<True_False> TFARRY = new ArrayList<True_False>();
	private int Qcounter;
	ArrayList<MCQ> M=new ArrayList<MCQ>();
	ArrayList<True_False> MM=new ArrayList<True_False>();
	ArrayList<String> Qus=new ArrayList<String>();

	@RequestMapping("/SingUpAsTeacher")
	public String SinUp() {
		return "SingUpAsTeacher";
	}

	@RequestMapping("/LogInAsTeacher")
	public String Log() {
		return "LogInAsTeacher";
	}

	@RequestMapping("/addTecher")
	public String addNewUser(@RequestParam String Fname, @RequestParam String Lname, @RequestParam String Uname,
			@RequestParam String Email, @RequestParam String Passwoed, @RequestParam int Age,
			@RequestParam String Gender) throws ClassNotFoundException {

		// account=new Teacher( Fname, Lname, Uname, Email, Passwoed,
		// Gender,Age,0);
		account.setFname(Fname);
		account.setLname(Lname);
		account.setUsrenName(Uname);
		account.setEmail(Email);
		account.setPassword(Passwoed);
		account.setGender(Gender);
		account.setAge(Age);
		account.setMaxScore(0);
		if (account.registeration(account)) {

			//System.out.println("MEEEEEEEEEDHHHAAATT");
			return "TeacherHomPage";
		}

		else
			return "SingUpAsTeacher";
	}

	@RequestMapping("/logintecher")
	public String loginastech(@RequestParam String Email, @RequestParam String Passwoed) throws ClassNotFoundException {
		account = new Teacher(account.CheckValidation(Email, Passwoed));
		if (Email.equals(account.getEmail()) & Passwoed.equals(account.getPassword())& account.getType().equals("Teacher")) {

			return "TeacherHomPage";
		} else {
			return "LogInAsTeacher";
		}
	}

	@RequestMapping("/CreateCourse")
	public String create() {
		return "CreateCourse";
	}

	@RequestMapping("/CREATCOURSE")
	public String creatcourse(@RequestParam String CourseName, @RequestParam String Description)
			throws ClassNotFoundException {

		Course course = new Course(CourseName, Description, account.getEmail());
		course.setCourse(course);
		return "TeacherHomPage";
	}

	@RequestMapping("/ShowCourses")
	public ModelAndView showCour() throws ClassNotFoundException {
		ModelAndView mv = new ModelAndView();
		ArrayList<String> arr = new ArrayList<String>();
		arr = course.showcorses();
		mv.setViewName("ShowCourses");
		mv.addObject("courses", arr);
		return mv;
	}

	@RequestMapping("/CreateGame")
	public ModelAndView showCours() throws ClassNotFoundException {
		ModelAndView mv = new ModelAndView();
		ArrayList<String> arr = new ArrayList<String>();
		arr = course.showcorses();
		mv.setViewName("AddGame");
		mv.addObject("courses", arr);
		return mv;
	}

	@RequestMapping("/selectCourse")
	public String slectCour(@RequestParam String GameName, @RequestParam String courseName, @RequestParam String answer)
			throws ClassNotFoundException {
		game.setGameName(GameName);
		game.setCourseName(courseName);
		game.setTeacherEmail(account.getEmail());

		if (answer.equals("MCQ")) {

			return "AddMCQ";
		} else {
			return "AddTF";
		}

	}

	@RequestMapping("/addmcqQuestion")
	public String addQ(@RequestParam String question, @RequestParam String Choice1, @RequestParam String Choice2,
			@RequestParam String Choice3, @RequestParam String Choice4, @RequestParam String answer,
			@RequestParam int answerQ) throws ClassNotFoundException {
		MCQ gam = new MCQ();
		ArrayList<String> ar = new ArrayList<String>();

		gam.setQuestion(question);
		ar.add(Choice1);
		ar.add(Choice2);
		ar.add(Choice3);
		ar.add(Choice4);
		gam.setChoice(ar);
		gam.setAnswer(ar.get(answerQ - 1));
		MCQARRY.add(gam);

		if (answer.equals("Yes")) {
			return "AddMCQ";
		} else {
			game.setType("MCQ");
			game.setMcq(MCQARRY);
			account.addMcq(game);
			game = new Game();
			System.out.println("Game added sucsussfuly ");
			return "TeacherHomPage";
		}

	}

	@RequestMapping("/addT_FQuestion")
	public String addT_F(@RequestParam String question, @RequestParam String answer, @RequestParam String answerQ)
			throws ClassNotFoundException {
		True_False gamtf = new True_False();

		gamtf.setQuestion(question);
		gamtf.setAnswer(answerQ);
		TFARRY.add(gamtf);
		if (answer.equals("Yes")) {
			return "AddTF";
		} else {
			game.setType("TF");
			game.setT_F(TFARRY);
			account.Addtf(game);
			game = new Game();
			System.out.println("Game added sucsussfuly ");
			return "TeacherHomPage";
		}

	}

	@RequestMapping("/PlayGame")
	public ModelAndView RetunCourses() throws ClassNotFoundException {
		ModelAndView mv = new ModelAndView();
		ArrayList<String> arr = new ArrayList<String>();
		arr = course.showcorses();
		mv.setViewName("PlayGame");
		mv.addObject("ccourses", arr);
		return mv;
	}
	@RequestMapping("/selctgames")
	public ModelAndView RetunGamesname(@RequestParam String coursename) throws ClassNotFoundException {
		ModelAndView mv = new ModelAndView();
		ArrayList<String> arr = new ArrayList<String>();
		System.out.println(coursename);
		arr = game.showgames(coursename );
		mv.setViewName("PlayGame");
		mv.addObject("gamesname", arr);
		return mv;
	}
	@RequestMapping("/selectgame")
	public String RetunGames(Model model,@RequestParam String gamnam) throws ClassNotFoundException {
		
		Game gam=new Game();
		System.out.println("sh"+ gamnam);
		gam=game.slectgame(gamnam);
		Qcounter=0;
				
			if(	gam.getType().equals("MCQ")){
				
				System.out.println("ay haga");
			M=gam.getMcq();
			System.out.println("asd"+M.get(0).getQuestion());
			model.addAttribute("questions", M.get(0));
			return "Playing";
			}
			else if(gam.getType().equals("TF")){
				
				
				MM=gam.getT_F();
				model.addAttribute("questions", MM.get(Qcounter));
				System.out.println(MM.get(Qcounter).getQuestion());
				System.out.println(MM.get(Qcounter).getAnswer());
				System.out.println(MM.get(Qcounter).getPoint());
				return "PlayingTF";
			}
		
		return "TeacherHomPage";
	}
	@RequestMapping("nextQuestion")
	public String update(Model model ,@RequestParam String Answe){
		
		if(MM.get(Qcounter).getAnswer().equals(Answe)){
			account.setMaxScore(account.getMaxScore()+MM.get(Qcounter).getPoint());
		}
		Qcounter++;
		if(Qcounter>=MM.size()){
			return "TeacherHomPage";
		
		}
		
		model.addAttribute("questions", MM.get(Qcounter));
		return "PlayingTF";
	
	}
	
	
}

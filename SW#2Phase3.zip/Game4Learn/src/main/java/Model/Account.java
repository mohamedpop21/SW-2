package Model;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Account {

	private String Fname;
	private String Lname;
	private String UsrenName;
	private String Email;
	private String Password;
	private String Gender;
	private int age;
	private int maxScore;
	private String Type;
	

	public String getType() {
		return Type;
	}

	public void setType(String type) {
		Type = type;
	}

	public String getFname() {
		return Fname;
	}

	public void setFname(String fname) {
		Fname = fname;
	}

	public String getLname() {
		return Lname;
	}

	public void setLname(String lname) {
		Lname = lname;
	}

	public String getUsrenName() {
		return UsrenName;
	}

	public void setUsrenName(String usrenName) {
		UsrenName = usrenName;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getMaxScore() {
		return maxScore;
	}

	public void setMaxScore(int maxScore) {
		this.maxScore = maxScore;
	}

	public Account(String fname, String lname, String usrenName, String email, String password, String gender, int age,
			int maxScore,String type) {
		super();
		Fname = fname;
		Lname = lname;
		UsrenName = usrenName;
		Email = email;
		Password = password;
		Gender = gender;
		this.age = age;
		this.maxScore = maxScore;
		this.Type=type;
	}

	public Account(Account c) {
		super();
		Fname = c.getFname();
		Lname = c.getLname();
		UsrenName = c.getUsrenName();
		Email = c.getEmail();
		Password = c.getPassword();
		Gender = c.getGender();
		this.age = c.getAge();
		this.maxScore = c.getMaxScore();
		this.Type=c.getType();
	}

	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}

	public static void connection() throws ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
	}

	public Game PlayGame(String c) throws IOException, ClassNotFoundException {
		Game game = new Game();

		return game;
	}

	public ArrayList<Course> showCourses() throws ClassNotFoundException {
		Course course = new Course();
		ArrayList<Course> c = new ArrayList<Course>();

		return c;
	}

	public ArrayList<Game> showgame(String c) throws ClassNotFoundException {

		Game game = new Game();
		ArrayList<Game> g = new ArrayList<Game>();
		return g;
	}

	/*
	 * public boolean login(String Email,String password) throws
	 * ClassNotFoundException {
	 * 
	 * if(CheckValidation(Email, password)) {
	 * 
	 * return true; } else { return false; } }
	 */
	public boolean registeration(Account acc) throws ClassNotFoundException {
		connection();

		if (CheckValidation(acc.getEmail()))
			return false;
		String url = "jdbc:mysql://localhost/my_game_db";
		String name = "root";
		String pass = "";
		Connection con;
		try {
			con = DriverManager.getConnection(url, name, pass);
			System.out.println("medhat");
			String sql = "insert into account (Fname,Lname,UsrenName,Email,Password,Gender,age,	maxScore,Type)"
					+ "values(\"" + acc.getFname() + "\",\"" + acc.getLname() + "\",\"" + acc.getUsrenName() + "\",\""
					+ acc.getEmail() + "\",\"" + acc.getPassword() + "\",\"" + acc.getGender() + "\"," + acc.getAge()
					+ "," + 0 + ",\""+acc.getType()+"\")";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.execute();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (acc.CheckValidation(acc.getEmail())) {
			return true;
		} else {
			return false;
		}
	}

	public Account CheckValidation(String Email, String Password) throws ClassNotFoundException {
		connection();
		String url = "jdbc:mysql://localhost/my_game_db";
		String name = "root";
		String pass = "";
		Account c = new Account();
		Connection con;
		try {
			con = DriverManager.getConnection(url, name, pass);
			String queryCheck = "SELECT * from 	account WHERE Email = \"" + Email + "\"" + "and 	Password = \""
					+ Password + "\"";
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(queryCheck);
			if (rs.absolute(1)) {

				c.setFname(rs.getString("Fname"));
				c.setLname(rs.getString("Lname"));
				c.setUsrenName(rs.getString("usrenName"));
				c.setEmail(rs.getString("email"));
				c.setPassword(rs.getString("password"));
				c.setGender(rs.getString("gender"));
				c.setAge(rs.getInt("age"));
				c.setMaxScore(rs.getInt("maxScore"));
				c.setType(rs.getString("Type"));
				con.close();
				return c;
			}
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return c;
	}

	public static boolean CheckValidation(String Email) throws ClassNotFoundException {
		connection();
		String url = "jdbc:mysql://localhost/my_game_db";
		String name = "root";
		String pass = "";
		Connection con;
		try {
			con = DriverManager.getConnection(url, name, pass);
			String queryCheck = "SELECT * from account WHERE Email = \"" + Email + "\"";
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(queryCheck); // execute the query,
														// and get a java
														// resultset
			// if this ID already exists, we quit
			if (rs.absolute(1)) {
				con.close();
				return true;
			}
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;

	}
}

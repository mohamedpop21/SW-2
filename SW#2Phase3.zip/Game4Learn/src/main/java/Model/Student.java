package Model;

public class Student extends Account {

}

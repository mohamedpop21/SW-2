package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Course {
	private String Name;
	private String Discribtion;
	private String TeacherEmail;

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getDiscribtion() {
		return Discribtion;
	}

	public void setDiscribtion(String discribtion) {
		Discribtion = discribtion;
	}

	public String getTeacherEmail() {
		return TeacherEmail;
	}

	public void setTeacherEmail(String teacherEmail) {
		TeacherEmail = teacherEmail;
	}

	public Course(String name, String discribtion, String teacherEmail) {
		super();
		Name = name;
		Discribtion = discribtion;
		TeacherEmail = teacherEmail;
	}

	public Course() {
		super();
		// TODO Auto-generated constructor stub
	}

	public static void connection() throws ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
	}

	public void setCourse(Course course) throws ClassNotFoundException {
		connection();
		String url = "jdbc:mysql://localhost/my_game_db";
		String name = "root";
		String pass = "";
		Connection con;
		try {
			con = DriverManager.getConnection(url, name, pass);
			System.out.println("medhat");
			String sql = "insert into Course (Name,Discribtion,TeacherEmail)" + "values(\"" + course.getName() + "\",\""
					+ course.getDiscribtion() + "\",\"" + course.getTeacherEmail() + "\")";
			PreparedStatement pst = con.prepareStatement(sql);
			pst.execute();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public ArrayList<String> showcorses() throws ClassNotFoundException {
		ArrayList<String> list = new ArrayList<String>();
		connection();
		String url = "jdbc:mysql://localhost/my_game_db";
		String name = "root";
		String pass = "";
		Connection con;
		try {
			con = DriverManager.getConnection(url, name, pass);
			System.out.println("medhat");
			String queryCheck1 = "SELECT Name from course";
			Statement st1 = con.createStatement();
			ResultSet rs1 = st1.executeQuery(queryCheck1);
			while (rs1.next()) {
				list.add(rs1.getString("Name"));

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
}
